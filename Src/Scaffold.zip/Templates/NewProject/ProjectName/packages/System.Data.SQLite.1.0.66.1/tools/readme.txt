If you face any SQLite related issues, check the official site:
http://system.data.sqlite.org/

If you have a problem running your application:
- If you are running a website in IIS 7.x:
   1- Open IIS
   2- Go to Application Pools
   3- Right click the app pool you use, 
        choose "Advanced Options"
   4- Make sure "Enable 32-bit Applications" is set to "True"

For more information and screenshots about configuration visit:
http://bit.ly/jm9TiY